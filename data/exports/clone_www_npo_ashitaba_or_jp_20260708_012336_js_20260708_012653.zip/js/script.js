{"@context":"https:\/\/schema.org","@graph":[{"@type":"BreadcrumbList","@id":"https:\/\/www.npo-ashitaba.or.jp\/#breadcrumblist","itemListElement":[{"@type":"ListItem","@id":"https:\/\/www.npo-ashitaba.or.jp#listItem","position":1,"name":"\u30db\u30fc\u30e0"}]},{"@type":"Organization","@id":"https:\/\/www.npo-ashitaba.or.jp\/#organization","name":"NPO\u6cd5\u4eba\u3042\u3057\u305f\u3070\u306e\u4f1a","description":"\u3042\u3057\u305f\u3070\u306e\u4f1a\u306f\u75c5\u6c17\u7642\u990a\u304b\u3089\u306e\u793e\u4f1a\u5fa9\u5e30\uff08\u5c31\u52b4\uff09\u3092\u652f\u63f4\u3059\u308bNPO\u6cd5\u4eba\u3067\u3059","url":"https:\/\/www.npo-ashitaba.or.jp\/","telephone":"+81424277789","logo":{"@type":"ImageObject","url":"https:\/\/www.npo-ashitaba.or.jp\/wp-content\/uploads\/2023\/06\/logo.png","@id":"https:\/\/www.npo-ashitaba.or.jp\/#organizationLogo","width":1116,"height":233},"image":{"@id":"https:\/\/www.npo-ashitaba.or.jp\/#organizationLogo"}},{"@type":"WebPage","@id":"https:\/\/www.npo-ashitaba.or.jp\/#webpage","url":"https:\/\/www.npo-ashitaba.or.jp\/","name":"NPO\u6cd5\u4eba\u3042\u3057\u305f\u3070\u306e\u4f1a","description":"\u3042\u3057\u305f\u3070\u306e\u4f1a\u306f\u75c5\u6c17\u7642\u990a\u304b\u3089\u306e\u793e\u4f1a\u5fa9\u5e30\uff08\u5c31\u52b4\uff09\u3092\u652f\u63f4\u3059\u308bNPO\u6cd5\u4eba\u3067\u3059","inLanguage":"ja","isPartOf":{"@id":"https:\/\/www.npo-ashitaba.or.jp\/#website"},"breadcrumb":{"@id":"https:\/\/www.npo-ashitaba.or.jp\/#breadcrumblist"},"datePublished":"2023-05-10T09:46:43+09:00","dateModified":"2023-05-10T09:46:43+09:00"},{"@type":"WebSite","@id":"https:\/\/www.npo-ashitaba.or.jp\/#website","url":"https:\/\/www.npo-ashitaba.or.jp\/","name":"NPO\u6cd5\u4eba\u3042\u3057\u305f\u3070\u306e\u4f1a","description":"\u3042\u3057\u305f\u3070\u306e\u4f1a\u306f\u75c5\u6c17\u7642\u990a\u304b\u3089\u306e\u793e\u4f1a\u5fa9\u5e30\uff08\u5c31\u52b4\uff09\u3092\u652f\u63f4\u3059\u308bNPO\u6cd5\u4eba\u3067\u3059","inLanguage":"ja","publisher":{"@id":"https:\/\/www.npo-ashitaba.or.jp\/#organization"}}]}

window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("set","linker",{"domains":["www.npo-ashitaba.or.jp"]});
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "G-2P21C58DNR");
gtag("config", "AW-419004833");
//# sourceURL=google_gtagjs-js-after

{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/ashitaba/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}

uscesL10n = {
			
			'ajaxurl': "https://www.npo-ashitaba.or.jp/wp-admin/admin-ajax.php",
			'loaderurl': "https://www.npo-ashitaba.or.jp/wp-content/plugins/usc-e-shop/images/loading.gif",
			'post_id': "3492",
			'cart_number': "3550",
			'is_cart_row': false,
			'opt_esse': new Array(  ),
			'opt_means': new Array(  ),
			'mes_opts': new Array(  ),
			'key_opts': new Array(  ),
			'previous_url': "https://www.npo-ashitaba.or.jp",
			'itemRestriction': "",
			'itemOrderAcceptable': "0",
			'uscespage': "",
			'uscesid': "MGNjM2ViNjg2OWIxMmI2NWVlODY2MTViNDkxN2QxMDg5MzQ3NjQ1OWE0MjVlNTVjX2FjdGluZ18wX0E%3D",
			'wc_nonce': "41733c3df0"
		}

jQuery('#rehabilitation .mw_wp_form form').addClass('h-adr');

jQuery('#donate .mw_wp_form form').addClass('h-adr');

{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://www.npo-ashitaba.or.jp/wp-includes/js/wp-emoji-release.min.js?ver=7.0"}}

/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=https://www.npo-ashitaba.or.jp/wp-includes/js/wp-emoji-loader.min.js

(function(){
  /* 押した時だけ出す隠しメニュー/オーバーレイ(fixed/absoluteで隠されている)は
     本来ずっと隠れているものなので、保険で強制表示しない(MENUが開いた状態で残るのを防ぐ)。 */
  function inHiddenOverlay(e){
    var n=e;
    while(n && n!==document.body){
      var s=getComputedStyle(n);
      if((s.position==='fixed'||s.position==='absolute') && (parseFloat(s.opacity)===0 || s.visibility==='hidden')) return true;
      n=n.parentElement;
    }
    return false;
  }
  function sweep(){
    var all = document.querySelectorAll("body *");
    for (var i = 0; i < all.length; i++) {
      var e = all[i];
      var cs = getComputedStyle(e);
      var hidden = (parseFloat(cs.opacity) === 0) || (cs.visibility === "hidden");
      if (hidden && inHiddenOverlay(e)) continue;
      if (parseFloat(cs.opacity) === 0) {
        e.style.setProperty("opacity", "1", "important");
        e.style.transform = "none";
      }
      if (cs.visibility === "hidden") e.style.setProperty("visibility", "visible", "important");
    }
  }
  setTimeout(sweep, 4000);
})();